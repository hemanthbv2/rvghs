<?php
/**
 * Plugin Name: RVGHS Chatbot Telemetry
 * Description: Dual-write telemetry receiver for the RVGHS Chatbot, storing logs in WordPress and forwarding to Vercel/MongoDB.
 * Version: 1.0.0
 * Author: Antigravity IDE
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('RVGHS_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include REST API endpoints
require_once RVGHS_CHATBOT_PLUGIN_DIR . 'api/rest-api.php';

// Include Admin Settings
require_once RVGHS_CHATBOT_PLUGIN_DIR . 'admin/settings-page.php';

// Create DB table on activation
register_activation_hook(__FILE__, 'rvghs_chatbot_create_db');
function rvghs_chatbot_create_db() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'rvghs_chatbot_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        session_id varchar(255) NOT NULL,
        query text NOT NULL,
        intent varchar(255) NOT NULL,
        timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        event_type varchar(50) DEFAULT 'message' NOT NULL,
        metadata text DEFAULT NULL,
        device varchar(255) DEFAULT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// ====== Proper Asset Enqueueing ======
function rvghs_chatbot_enqueue_assets() {
    $plugin_url = plugin_dir_url( __FILE__ );

    // Enqueue Phosphor icons
    wp_enqueue_script('phosphor-icons', 'https://unpkg.com/@phosphor-icons/web', array(), null, false);

    // Enqueue CSS
    wp_enqueue_style(
        'rvghs-chatbot-style',
        $plugin_url . 'assets/index.css',
        array(),
        time()
    );

    // Enqueue JS
    wp_enqueue_script(
        'rvghs-chatbot-script',
        $plugin_url . 'assets/app.js',
        array(),
        time(),
        true
    );

    // Pass AJAX URL to script
    wp_localize_script( 'rvghs-chatbot-script', 'rvghsChatbotAjax', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' )
    ));
}
add_action( 'wp_enqueue_scripts', 'rvghs_chatbot_enqueue_assets' );

// ====== Inject Chatbot HTML into Footer ======
function rvghs_chatbot_inject_html() {
    $plugin_url = plugin_dir_url( __FILE__ );
    ?>
    <!-- Floating Launcher -->
    <button class="chat-launcher" id="chatLauncher" title="Chat with us!">
        <img src="<?php echo esc_url($plugin_url . 'assets/mascot_v2.png'); ?>" alt="Chat Mascot" class="launcher-mascot" id="launcherMascotImg">
    </button>

    <!-- Chat Widget -->
    <div class="chat-widget" id="chatWidget" style="display: none;">
        <div class="chat-header">
            <div class="header-info">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <!-- School Logo -->
                    <img src="<?php echo esc_url($plugin_url . 'assets/Logo.png'); ?>" alt="School Logo" class="header-logo" style="width: 35px; height: 35px; border-radius: 50%; object-fit: cover; background: white; padding: 2px;">
                    <div>
                        <h2 id="chatSchoolName" style="margin: 0; font-size: 16px; font-weight: 600;">RV Girls High School</h2>
                        <div class="status"><span class="dot"></span> Online</div>
                    </div>
                </div>
            </div>
            <div class="header-actions">
                <button id="clearChatBtn" title="Clear chat" style="display: inline-flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2v6h-6"></path><path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path><path d="M3 22v-6h6"></path><path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path></svg></button>
                <button id="closeChatBtn" title="Close chat">✖</button>
            </div>
        </div>
        <div class="chat-body" id="chatBody" style="position: relative;">
            <!-- Hero Screen -->
            <div id="rvghs-hero-screen" class="hero-screen">
                <img src="<?php echo esc_url($plugin_url . 'assets/mascot_v2.png'); ?>" alt="Mascot" class="hero-mascot">
                <div class="hero-sign">Welcome to RV Girls High School!</div>
            </div>
            <div class="chat-container" id="chatContainer"></div>
        </div>
        <div class="chat-input-area" style="position: relative;">
            <div class="quick-suggestions" id="quickSuggestions">
                <button class="suggestion-chip" data-query="menu">📋 Menu</button>
                <button class="suggestion-chip" data-query="admissions">📚 Admissions</button>
                <button class="suggestion-chip" data-query="fees">💰 Fees</button>
            </div>
            <div id="typeahead" class="typeahead-container hidden"></div>
            <div class="chat-input-wrapper">
                <button id="micBtn" class="mic-btn" title="Voice Search"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="22"></line></svg></button>
                <input type="text" id="chatInput" placeholder="Type a message…" autocomplete="off" />
                <button class="send-btn" id="sendBtn" title="Send">➤</button>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'rvghs_chatbot_inject_html', 999 );
